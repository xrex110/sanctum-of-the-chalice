public class Heading {
	public MapCoordinate position;
	public Direction direction;

	public Heading(MapCoordinate pos, Direction dir) {
		this.position = pos;
		this.direction = dir;
	}
}
