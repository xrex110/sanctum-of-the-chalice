public class Tester {
	public static void main(String[] args) {
		Generator gen = new Generator(6);
		gen.generateDungeon();
	}
}
