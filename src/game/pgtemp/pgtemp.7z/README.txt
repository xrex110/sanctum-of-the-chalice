Compile all files in this folder,
and run Tester
